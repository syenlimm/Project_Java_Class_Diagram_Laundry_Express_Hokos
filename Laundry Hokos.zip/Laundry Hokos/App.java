import java.util.ArrayList;
import java.util.Scanner;

public class App {
    static Scanner in = new Scanner(System.in);
    
    static ArrayList<Kasir> daftarKasir = new ArrayList<>();

    static String inputText(String label) {
        System.out.print(label + " : ");
        return in.nextLine().trim();
    }

    static double inputAngka(String label) {
        while (true) {
            try {
                System.out.print(label + " : ");
                return Double.parseDouble(in.nextLine().trim().replace(",", "."));
            } catch (NumberFormatException e) {
                System.out.println("Harus angka, coba lagi.");
            }
        }
    }

    public static void main(String[] args) {
        boolean isRunning = true;
        
        while (isRunning) {
            System.out.println("\n=== MENU SISTEM LAUNDRY ===");
            System.out.println("1. Registrasi Kasir");
            System.out.println("2. Login & Buat Transaksi");
            System.out.println("0. Keluar Aplikasi");
            int menu = (int) inputAngka("Pilih Menu");

            if (menu == 1) {
                registrasiKasir();
            } else if (menu == 2) {
                Kasir kasirAktif = login();
                if (kasirAktif != null) {
                    kasirAktif.signIn(); 
                    buatTransaksi(kasirAktif);
                }
            } else if (menu == 0) {
                isRunning = false;
                System.out.println("Terima kasih telah menggunakan sistem ini.");
            } else {
                System.out.println("Pilihan tidak valid.");
            }
        }
    }

    static void registrasiKasir() {
        System.out.println("\n=== REGISTRASI KASIR ===");
        Kasir kasirBaru = new Kasir(
                inputText("Kode"), inputText("Nama"), inputText("No HP"),
                inputText("Username"), inputText("Password"));
        
        daftarKasir.add(kasirBaru);
        kasirBaru.signUp(); 
        System.out.println("Registrasi selesai! Silakan pilih menu Login untuk membuat transaksi.");
    }

    static Kasir login() {
        System.out.println("\n=== LOGIN KASIR ===");
        if (daftarKasir.isEmpty()) {
            System.out.println("Belum ada data kasir. Silakan registrasi terlebih dahulu!");
            return null;
        }

        String uname = inputText("Username");
        String pass = inputText("Password");

        for (Kasir kasir : daftarKasir) {
            if (kasir.getUsername().equals(uname) && kasir.getPassword().equals(pass)) {
                return kasir; 
            }
        }
        
        System.out.println("Username atau Password salah!");
        return null;
    }

    static void buatTransaksi(Kasir kasir) {
        System.out.println("\n=== DATA CUSTOMER ===");
        Customer customer = new Customer(
                inputText("Kode"), inputText("Nama"), inputText("No HP"), inputText("Alamat"));

        System.out.println("\n=== DATA NOTA ===");
        
        int angkaRandom = (int) (Math.random() * 9000) + 1000;
        String noNotaOtomatis = "INV-" + angkaRandom;
        System.out.println("No Nota : " + noNotaOtomatis);

        Nota nota = new Nota(noNotaOtomatis, inputText("Tanggal"), kasir, customer);

        int pilih;
        do {
            System.out.println("\n=== TAMBAH LAYANAN ===");
            System.out.println("1. Pakaian Kiloan");
            System.out.println("2. Handuk / Sprei / Selimut");
            System.out.println("3. Sepatu");
            System.out.println("0. Selesai");
            pilih = (int) inputAngka("Pilih");

            if (pilih == 1) {
                nota.addLayanan(new Kiloan(
                        inputText("Kode Layanan"), inputText("Nama Layanan"),
                        inputAngka("Harga per kg"), inputAngka("Berat (kg)")));
            } 
            
            else if (pilih == 2) {
                // FITUR BARU: Pisahkan Kiloan dan Satuan
                System.out.println("--- Pilih Metode Hitung ---");
                int metode = (int) inputAngka("1. Kiloan | 2. Satuan (Pilih 1/2)");
                
                if (metode == 1) {
                    nota.addLayanan(new Kiloan(
                            inputText("Kode Layanan"), 
                            inputText("Nama Layanan"),
                            inputAngka("Harga per kg"), 
                            inputAngka("Berat (kg)")));
                } else if (metode == 2) {
                    nota.addLayanan(new Handuk(
                            inputText("Kode Layanan"), 
                            inputText("Nama Layanan"),
                            inputAngka("Harga per pcs"), 
                            inputText("Jenis Barang (Handuk/Sprei/Selimut)"), 
                            inputText("Ukuran (Kecil/Besar)")));
                } else {
                    System.out.println("Pilihan metode tidak valid.");
                }
            } 
            
            else if (pilih == 3) {
                nota.addLayanan(new Sepatu(
                        inputText("Kode Layanan"), 
                        (int) inputAngka("Jenis Layanan (1.Fast / 2.Deep)"), 
                        inputText("Jenis Barang"), 
                        inputText("Jenis Sepatu")));
                        
            } else if (pilih != 0) {
                System.out.println("Pilihan tidak valid.");
            }
        } while (pilih != 0);

        nota.setDiskon(inputAngka("\nDiskon (0 jika tidak ada)"));
        nota.setStatusBayar(inputText("Status Bayar (Lunas/Belum)"));

        System.out.println();
        nota.struk(); 
    }
}