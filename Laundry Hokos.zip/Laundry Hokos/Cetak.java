public interface Cetak {
    String TOKO = "LaundryExpressHokos.id";
    String ALAMAT = "Tomang, Jakarta Barat";

    void struk();
}