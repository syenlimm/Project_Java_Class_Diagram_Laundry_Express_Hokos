public class DetailNota {

    // berat (kg) untuk layanan Kiloan, atau jumlah pcs untuk layanan Satuan
    private double jumlah;

    // peran "layanan" pada relasi DetailNota -> Layanan
    private Layanan layanan;

    public DetailNota(Layanan layanan, double jumlah) {
        this.layanan = layanan;
        this.jumlah = jumlah;
    }

    public DetailNota() {
    }

    public void setJumlah(double jumlah) {
        this.jumlah = jumlah;
    }

    public void setLayanan(Layanan layanan) {
        this.layanan = layanan;
    }

    public double getJumlah() {
        return jumlah;
    }

    public Layanan getLayanan() {
        return layanan;
    }

    // subtotal item ini = dihitung oleh layanan (Kiloan / Satuan) berdasarkan jumlah
    public double calcSubTotal() {
        if (layanan == null) {
            return 0;
        }
        return layanan.calcSubtotal(jumlah);
    }
}