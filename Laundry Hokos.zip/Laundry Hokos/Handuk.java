public class Handuk extends Satuan {
    private String ukuran;

    public Handuk(String kodeLayanan, String namaLayanan, double hargaSatuan,
                  String jenisBarang, String ukuran) {
        super(kodeLayanan, namaLayanan, hargaSatuan, jenisBarang);
        this.ukuran = ukuran;
    }

    public Handuk() {
        super();
    }

    public void setUkuran(String ukuran) { 
        this.ukuran = ukuran; 
    }

    public String getUkuran() { 
        return ukuran; 
    }

    // Method baru untuk menghitung total harga berdasarkan ukuran handuk
    public double hitungHarga() {
        // Mengambil harga dasar dari parent class Satuan
        double hargaDasar = getHargaSatuan(); 
        
        // Pengecekan ukuran menggunakan huruf kecil semua agar tidak case-sensitive
        if (ukuran == null) {
            return hargaDasar;
        }

        switch (ukuran.toLowerCase()) {
            case "kecil":
                return hargaDasar;             // Harga dasar (tidak ada tambahan)
            case "sedang":
                return hargaDasar + 5000;      // Contoh: Tambah Rp5.000 untuk ukuran Sedang
            case "besar":
                return hargaDasar + 15000;     // Contoh: Tambah Rp15.000 untuk ukuran Besar
            default:
                return hargaDasar;             // Jika ukuran tidak dikenali, gunakan harga dasar
        }
    }
}