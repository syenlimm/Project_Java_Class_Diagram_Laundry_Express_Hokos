public class Satuan extends Layanan {
    private String jenisBarang;

    public Satuan(String kodeLayanan, String namaLayanan, double hargaSatuan, String jenisBarang) {
        super(kodeLayanan, namaLayanan, hargaSatuan);
        this.jenisBarang = jenisBarang;
    }

    public Satuan() {
        super();
    }

    public void setJenisBarang(String jenisBarang) { this.jenisBarang = jenisBarang; }

    public String getJenisBarang() { return jenisBarang; }

    @Override
    public double calcSubtotal(double hargaSatuan) {
        return hargaSatuan; // 1 item = harga satuan
    }
}