public class Sepatu extends Satuan {
    private String jenisSepatu;

    // Perhatikan bagian ini: Sekarang dia menerima "int pilihanCuci"
    public Sepatu(String kodeLayanan, int pilihanCuci, String jenisBarang, String jenisSepatu) {
        // melempar data ke parent class (Satuan)
        super(
            kodeLayanan, 
            (pilihanCuci == 2) ? "Deep Cleaning Sepatu" : "Fast Cleaning Sepatu", // Nama otomatis
            (pilihanCuci == 2) ? 70000.0 : 30000.0,                               // Harga otomatis (ditambah .0 agar jadi double)
            jenisBarang
        );
        
        this.jenisSepatu = jenisSepatu;
    }

    public Sepatu() {
        super();
    }

    public void setJenisSepatu(String jenisSepatu) { this.jenisSepatu = jenisSepatu; }

    public String getJenisSepatu() { return jenisSepatu; }
}