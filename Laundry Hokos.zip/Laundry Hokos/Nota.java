import java.util.ArrayList;
import javax.swing.JOptionPane; 
import java.io.FileWriter; // Tambahan untuk menulis file
import java.io.IOException; // Tambahan untuk menangani error file

public class Nota implements Cetak {
    private String noNota;
    private String tglFaktur;
    /** Association **/
    private ArrayList<Layanan> listLayanan;
    private Kasir kasir;
    private Customer customer;
    /****************/
    private String statusBayar;
    private double subTotal;
    private double diskon;
    private double totalBayar;

    public Nota(String noNota, String tglFaktur, Kasir kasir, Customer customer) {
        this.noNota = noNota;
        this.tglFaktur = tglFaktur;
        this.kasir = kasir;
        this.customer = customer;
        this.listLayanan = new ArrayList<>();
        this.diskon = 0;
    }

    public Nota() {
        this.listLayanan = new ArrayList<>();
        this.diskon = 0;
    }

    public void addLayanan(Layanan layanan) {
        listLayanan.add(layanan);
    }

    public ArrayList<Layanan> getListLayanan() {
        return listLayanan;
    }

    public double calcSubTotal() {
        subTotal = 0;
        for (Layanan l : listLayanan) {
            subTotal += l.calcSubtotal(l.getHargaSatuan());
        }
        return subTotal;
    }

    public double calcTotalBayar() {
        totalBayar = calcSubTotal() - diskon;
        return totalBayar;
    }

    /* setters */
    public void setNoNota(String noNota) { this.noNota = noNota; }
    public void setTglFaktur(String tglFaktur) { this.tglFaktur = tglFaktur; }
    public void setStatusBayar(String statusBayar) { this.statusBayar = statusBayar; }
    public void setDiskon(double diskon) { this.diskon = diskon; }

    /* getters */
    public String getNoNota() { return noNota; }
    public String getTglFaktur() { return tglFaktur; }
    public Kasir getKasir() { return kasir; }
    public Customer getCustomer() { return customer; }
    public String getStatusBayar() { return statusBayar; }

    @Override
    public void struk() {
        StringBuilder sb = new StringBuilder();
        
        sb.append("=== ").append(Cetak.TOKO).append(" ===\n");
        sb.append(Cetak.ALAMAT).append("\n\n");
        sb.append("No Nota  : ").append(noNota).append("\n");
        sb.append("Tanggal  : ").append(tglFaktur).append("\n");
        sb.append("Kasir    : ").append(kasir.getNama()).append("\n");
        sb.append("Customer : ").append(customer.getNama()).append("\n");
        sb.append("------------------------------------------\n");
        
        for (Layanan l : listLayanan) {
            sb.append("- ").append(l.getNamaLayanan())
              .append(" : Rp ").append(l.calcSubtotal(l.getHargaSatuan())).append("\n");
        }
        
        sb.append("------------------------------------------\n");
        sb.append("Subtotal : Rp ").append(calcSubTotal()).append("\n");
        sb.append("Diskon   : Rp ").append(diskon).append("\n");
        sb.append("Total    : Rp ").append(calcTotalBayar()).append("\n");
        sb.append("Status   : ").append(statusBayar).append("\n");

        // 1. Menampilkan Popup (Tetap dipertahankan)
        JOptionPane.showMessageDialog(null, sb.toString(), "Struk Transaksi - " + noNota, JOptionPane.INFORMATION_MESSAGE);

        // 2. FITUR BARU: Menyimpan teks ke dalam file .txt
        try {
            // Nama file akan otomatis menyesuaikan Nomor Nota, misal: Nota_001.txt
            String namaFile = "Nota_" + noNota + ".txt";
            FileWriter writer = new FileWriter(namaFile);
            writer.write(sb.toString()); // Menulis isi StringBuilder ke file
            writer.close();
            
            System.out.println("Berhasil menyimpan struk ke file: " + namaFile);
        } catch (IOException e) {
            System.out.println("Gagal menyimpan file TXT: " + e.getMessage());
        }
    }
}