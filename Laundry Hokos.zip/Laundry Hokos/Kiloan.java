public class Kiloan extends Layanan {
    private double beratKg;

    public Kiloan(String kodeLayanan, String namaLayanan, double hargaSatuan, double beratKg) {
        super(kodeLayanan, namaLayanan, hargaSatuan);
        this.beratKg = beratKg;
    }

    public Kiloan() {
        super();
    }

    public void setBeratKg(double beratKg) { this.beratKg = beratKg; }

    public double getBeratKg() { return beratKg; }

    @Override
    public double calcSubtotal(double hargaSatuan) {
        return hargaSatuan * beratKg;
    }
}