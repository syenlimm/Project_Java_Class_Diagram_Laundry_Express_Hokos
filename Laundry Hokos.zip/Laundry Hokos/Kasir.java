public class Kasir extends Person implements Login {
    private String username;
    private String password;

    public Kasir(String kode, String nama, String noHP,
                 String username, String password) {
        super(kode, nama, noHP);
        this.username = username;
        this.password = password;
    }

    public Kasir() {
        super();
    }

    public void setUsername(String username) { this.username = username; }
    public void setPassword(String password) { this.password = password; }


    public String getUsername() { return username; }
    public String getPassword() { return password; }

    @Override
    public void signUp() {
        System.out.println("Sign up berhasil untuk kasir: " + username);
    }

    @Override
    public void signIn() {
        System.out.println("Sign in berhasil, kasir: " + username);
    }
}