public class Layanan {
    private String kodeLayanan;
    private String namaLayanan;
    private double hargaSatuan;

    public Layanan(String kodeLayanan, String namaLayanan, double hargaSatuan) {
        this.kodeLayanan = kodeLayanan;
        this.namaLayanan = namaLayanan;
        this.hargaSatuan = hargaSatuan;
    }

    public Layanan() {
    }

    public void setKodeLayanan(String kodeLayanan) { this.kodeLayanan = kodeLayanan; }
    public void setNamaLayanan(String namaLayanan) { this.namaLayanan = namaLayanan; }
    public void setHargaSatuan(double hargaSatuan) { this.hargaSatuan = hargaSatuan; }

    public String getKodeLayanan() { return kodeLayanan; }
    public String getNamaLayanan() { return namaLayanan; }
    public double getHargaSatuan() { return hargaSatuan; }

    public double calcSubtotal(double jumlah) {
        return hargaSatuan * jumlah;
    }
}