public class Customer extends Person {
    private String alamat;

    public Customer(String kode, String nama, String noHP, String alamat) {
        super(kode, nama, noHP);
        this.alamat = alamat;
    }

    public Customer() {
        super();
    }

    public void setAlamat(String alamat) { this.alamat = alamat; }

    public String getAlamat() { return alamat; }
}